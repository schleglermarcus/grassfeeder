#![no_std]

pub use serde_json::*;
