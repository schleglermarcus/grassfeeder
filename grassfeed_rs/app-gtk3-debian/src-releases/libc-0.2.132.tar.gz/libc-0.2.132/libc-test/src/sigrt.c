#include <signal.h>

int sigrtmax() {
  return SIGRTMAX;
}

int sigrtmin() {
  return SIGRTMIN;
}
