## Run I18n extract in dev

When we want test `cargo i18n` in local dev, we can:

```bash
$ cargo run -- i18n ~/work/some-rust-project
```
