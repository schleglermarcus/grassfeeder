This is a minimal example of [rust-i18n](https://github.com/longbridgeapp/rust-i18n/).
