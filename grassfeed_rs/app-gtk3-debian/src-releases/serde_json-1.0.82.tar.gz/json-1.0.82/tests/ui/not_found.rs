use serde_json::json;

fn main() {
    json!({ "a" : x });
}
