## Unreleased

## 0.1.2

- Changed
  - Update bundled libwebp from 1.1.0 to 1.2.0 https://github.com/qnighy/libwebp-sys2-rs/pull/2
- Added
  - Support libwebp-1.2.0's `qmin`/`qmax` https://github.com/qnighy/libwebp-sys2-rs/pull/2
- Misc
  - Setup GitHub Actions https://github.com/qnighy/libwebp-sys2-rs/pull/1

## 0.1.1

- Carved out from [qnighy/libwebp-rs](https://github.com/qnighy/libwebp-rs) to [qnighy/libwebp-sys2-rs](https://github.com/qnighy/libwebp-sys2-rs).

## 0.1.0

Initial release.
