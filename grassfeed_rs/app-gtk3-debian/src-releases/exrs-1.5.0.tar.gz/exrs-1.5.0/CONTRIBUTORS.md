This is a list of contributors to the exrs project.

* [Johannes Vollmer](https://github.com/johannesvollmer)
* [Mandeep Bhutani](https://github.com/mandeep)
* [Daniel Santana](https://github.com/dgsantana)
* [Karel Peeters](https://github.com/KarelPeeters)
* [Dorian Fevrier](https://github.com/Narann)

Thank you for your time and efforts that you spent to improve the exrs project!
