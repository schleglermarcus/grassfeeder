# Changelog

## \[0.4.0]

- Update to gtk 0.15
  - [4aa6f17](https://github.com/tauri-apps/javascriptcore-rs/commit/4aa6f1758343f50cc7f7af42ac903077349b8051) Update to gtk 0.15 on 2022-01-18

## \[0.3.3]

- Regenerate with latest gir-files
  - [68fa7e5](https://github.com/tauri-apps/javascriptcore-rs/commit/68fa7e5f12110ac47c07afaaeebfeb7067dfca21) Add change file on 2021-11-04

## \[0.3.1]

- Update url in Cargo.toml.
  - [02b8c18](https://github.com/tauri-apps/javascriptcore-rs/commit/02b8c1829ca828866df8965b0c904372ba335960) Update url in Cargo.toml of sys crate on 2021-10-25

## \[0.3.0]

- Update Gir files
  - [3262e96](https://github.com/tauri-apps/javascriptcore-rs/commit/3262e96efc1cd6a640b81368255f3ae9325b2170) Bump version on 2021-10-04
