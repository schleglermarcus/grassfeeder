servo-style
===========

Style system for Servo, using [rust-cssparser](https://github.com/mozilla-servo/rust-cssparser) for parsing.

 * [Documentation](https://github.com/servo/servo/blob/master/docs/components/style.md).
