hashglobe
========


This is a fork of Rust's `std::HashMap`. It works on stable out of the stdlib and has fallible APIs.

We intend to diverge as little as possible from the original hashmap.


Dual licensed Apache/MIT, the same as the stdlib.


## Should I use this?

No.

Wait for https://github.com/rust-lang/rfcs/pull/2116 instead.
