Copyrights:

Lohengrin_-_Illustrated_Sporting_and_Dramatic_News.png: Public Domain, according to Wikimedia
kodim*.png: Eastman Kodak Company, released for unrestricted use
Transparency.png: Public Domain, according to Wikimedia

The images use different filtering:
Lohengrin: no filtering
kodim02: mixed
kodim07: mainly paeth
kodim17: mainly sub
kodim23: mixed
