This directory contains benchmark corpora. Each sub-directory contains a README
documenting the corpus a bit more.
