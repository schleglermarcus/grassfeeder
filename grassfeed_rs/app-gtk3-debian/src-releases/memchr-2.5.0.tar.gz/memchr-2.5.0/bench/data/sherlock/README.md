These were the original inputs used for the memchr benchmarks. In theory, they
could be replaced with the subtitle text in order to trim down the number of
inputs we use in the benchmark suite.

The nice thing about the subtitle corpus is that it gives us a translation into
Russian and Chinese, which lets us measure our code on non-ASCII text.
