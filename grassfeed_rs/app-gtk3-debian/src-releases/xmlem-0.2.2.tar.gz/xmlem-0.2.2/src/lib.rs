pub mod display;
mod document;
mod element;
mod key;
mod select;
mod value;

pub use document::{Declaration, Document};
pub use element::{Element, NewElement};
pub use key::Node;
pub use select::Selector;

#[cfg(test)]
mod tests {
    use std::str::FromStr;

    use qname::qname;

    use crate::select::Selector;

    use super::*;

    #[test]
    fn test() {
        use indexmap::IndexMap;

        use crate::document::Document;

        let mut doc = Document::new("root");

        let new_el = doc.root().append_new_element(
            &mut doc,
            NewElement {
                name: qname!("child"),
                attrs: Default::default(),
            },
        );
        new_el.append_new_element(
            &mut doc,
            NewElement {
                name: qname!("child2"),
                attrs: Default::default(),
            },
        );
        let mut attrs = IndexMap::new();
        attrs.insert(qname!("hello"), "yes".into());
        attrs.insert(qname!("another-thing"), "yes".into());

        let foo = new_el.append_new_element(
            &mut doc,
            NewElement {
                name: "with-child2".parse().unwrap(),
                attrs,
            },
        );
        foo.append_new_element(
            &mut doc,
            NewElement {
                name: "child3".parse().unwrap(),
                attrs: Default::default(),
            },
        );
        foo.append_new_element(
            &mut doc,
            NewElement {
                name: "child3".parse().unwrap(),
                attrs: Default::default(),
            },
        );
        foo.append_new_element(
            &mut doc,
            NewElement {
                name: "child3".parse().unwrap(),
                attrs: Default::default(),
            },
        );
        new_el.append_new_element(
            &mut doc,
            NewElement {
                name: "child2".parse().unwrap(),
                attrs: Default::default(),
            },
        );

        let _potato = doc.root().append_new_element(
            &mut doc,
            NewElement {
                name: "potato".parse().unwrap(),
                attrs: Default::default(),
            },
        );

        foo.parent(&mut doc)
            .unwrap()
            .remove_child(&mut doc, Node::Element(foo));

        println!("{}", doc);
    }

    #[test]
    fn smoke2() {
        let doc = Document::from_str(
            r#"<root xmlns:x="http://lol" someattr="true">lol <x:sparta/><sparta derp="9000"></sparta> </root>"#,
        ).unwrap();
        println!("{}", doc);
    }

    #[test]
    fn smoke3() {
        let input = r#"<俄语 լեզու="ռուսերեն">данные</俄语>"#;
        let doc = Document::from_str(input).unwrap();

        println!("{}", doc);
    }

    #[test]
    fn smoke4() {
        let input = "<root>ذ&amp;اكرة USB كبيرة السعة التخزينية (عصا، قرص ذاكرة USB)...</root>";
        let doc = Document::from_str(input).unwrap();

        println!("{}", doc);
    }

    #[test]
    fn smoke5() {
        let input = "<root>
            Text text &#x202d;text text
            &#x202e;text text &#x202d;text text
        </root>";
        let doc = Document::from_str(input).unwrap();

        println!("{}", doc);
    }

    #[test]
    fn clone() {
        let input = r#"<俄语 լեզու="ռուսերեն">данные</俄语>"#;
        let doc = Document::from_str(input).unwrap();
        let mut doc2 = doc.clone();

        let root = doc2.root();
        root.append_new_element(
            &mut doc2,
            NewElement {
                name: "lol".parse().unwrap(),
                attrs: Default::default(),
            },
        );

        println!("{}", doc);
        println!("{}", doc2);
    }

    #[test]
    fn long_attrs() {
        let input = r#"<root attribute1="potato potato potato"
            attribute2="potato potato potato"
            attribute3="potato potato potato"
            attribute4="potato potato potato"
        >
            <interesting attribute1="potato potato potato" attribute2="potato potato potato"
            />
            <another-one/>
        </root>
        "#;
        let doc = Document::from_str(input).unwrap();
        println!("{:#4.120}", doc);
        println!("{:#2.60}", doc);
        println!("{:#1.400}", doc);
    }

    #[test]
    fn hmm() {
        let input = "<?xml version=\"1.1\" ?>some random text<![CDATA[<hahaha>]]><!DOCTYPE root ahh ahhhh><!-- pre --><root/><!-- comment --> some other text";
        let doc = Document::from_str(input).unwrap();
        println!("{:#}", doc);
    }

    #[test]
    fn after() {
        let input = "<root><a/><b/><c/><d/></root>";
        let mut doc = Document::from_str(input).unwrap();

        let b = doc
            .root()
            .query_selector(&doc, &Selector::new("b").unwrap())
            .unwrap();
        b.append_new_element_after(&mut doc, ("potato", [("hihi", "oij")]));

        let d = doc
            .root()
            .query_selector(&doc, &Selector::new("d").unwrap())
            .unwrap();
        d.append_new_element_after(&mut doc, ("potato", [("hihi", "oij")]));
        println!("{:#}", doc);
    }

    #[test]
    fn after2() {
        let input = r#"<merge xmlns:latin="http://schemas.android.com/apk/res-auto">
            <include latin:keyboardLayout="@xml/key_styles_common" />
            <include latin:keyboardLayout="@xml/row_qwerty4" />
        </merge>"#;
        let mut doc = Document::from_str(input).unwrap();

        let include_selector = Selector::new("include").expect("this selector is fine");
        let rows_include = doc
            .root()
            .query_selector(&mut doc, &include_selector)
            .expect("there should be an include");

        let row_append = rows_include.append_new_element_after(
            &mut doc,
            NewElement {
                name: qname!("Row"),
                attrs: [].into(),
            },
        );

        row_append.append_new_element(
            &mut doc,
            NewElement {
                name: qname!("include"),
                attrs: [
                    (qname!("latin:keyboardLayout"), "@xml/potato".to_string()),
                    (qname!("latin:keyWidth"), "8.18%p".to_owned()),
                ]
                .into(),
            },
        );
        let row_append = row_append.append_new_element_after(
            &mut doc,
            NewElement {
                name: qname!("Row"),
                attrs: [].into(),
            },
        );

        row_append.append_new_element(
            &mut doc,
            NewElement {
                name: qname!("include"),
                attrs: [
                    (qname!("latin:keyboardLayout"), "@xml/potato".to_string()),
                    (qname!("latin:keyWidth"), "8.18%p".to_owned()),
                ]
                .into(),
            },
        );
        println!("{:#}", doc);
    }

    #[test]
    fn set_text() {
        let input = "<root><a/></root>";
        let mut doc = Document::from_str(input).unwrap();

        doc.root().set_text(&mut doc, "potato");

        println!("{:#}", doc);
    }

    #[test]
    fn double_use() {
        let input = "<root><a/></root>";
        let mut doc = Document::from_str(input).unwrap();

        let a = doc
            .root()
            .query_selector(&doc, &Selector::new("a").unwrap())
            .unwrap();
        doc.root().remove_child(&mut doc, Node::Element(a));
        assert_eq!(a.parent(&doc), None);

        let inner = doc.root().append_new_element(
            &mut doc,
            NewElement {
                name: qname!("test"),
                attrs: Default::default(),
            },
        );

        inner.append_element(&mut doc, a);
        println!("{:#}", doc);
    }

    #[test]
    fn selector() {
        let input =
            r#"<strings><string name="english_ime_name">Giella Keyboard</string></strings>"#;
        let doc = Document::from_str(input).unwrap();

        let sel = Selector::new(r#"string[name="english_ime_name"]"#).unwrap();
        let _el = doc.root().query_selector(&doc, &sel).unwrap();
    }
}
