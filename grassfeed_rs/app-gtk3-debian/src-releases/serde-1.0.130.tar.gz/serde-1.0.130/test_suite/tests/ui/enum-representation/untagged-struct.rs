use serde_derive::Serialize;

#[derive(Serialize)]
#[serde(untagged)]
struct S;

fn main() {}
