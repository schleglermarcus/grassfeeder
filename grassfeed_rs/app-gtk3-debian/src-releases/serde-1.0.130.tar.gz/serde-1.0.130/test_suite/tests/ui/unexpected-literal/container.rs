use serde_derive::Serialize;

#[derive(Serialize)]
#[serde("literal")]
struct S;

fn main() {}
