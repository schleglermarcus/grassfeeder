use crate::define_c_api;

define_c_api!(chacha8, ChaCha8, 64);
