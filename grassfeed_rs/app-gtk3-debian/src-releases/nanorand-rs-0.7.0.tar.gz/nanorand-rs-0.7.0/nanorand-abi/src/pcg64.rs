use crate::define_c_api;

define_c_api!(pcg64, Pcg64, 8);
