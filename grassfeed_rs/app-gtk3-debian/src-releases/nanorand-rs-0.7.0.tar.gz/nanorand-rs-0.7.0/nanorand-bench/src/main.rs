fn main() {
	println!("This is meant to be ran with `cargo bench`!");
}
