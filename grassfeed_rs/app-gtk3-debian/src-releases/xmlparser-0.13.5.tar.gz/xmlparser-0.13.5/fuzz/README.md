## Prepare

```
cargo install cargo-fuzz
```

## Run

```
cd ..
cargo +nightly fuzz run fuzz_xml
```
