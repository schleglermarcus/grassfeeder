---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

- [ ] Note that this crate implements the [URL Standard](https://url.spec.whatwg.org/) not RFC 1738 or RFC 3986

**Describe the bug**
A clear and concise description of what the bug is. Include code snippets if possible.
