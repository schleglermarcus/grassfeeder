```console
$ 02_apps --help
MyApp 1.0
Kevin K. <kbknapp@gmail.com>
Does awesome things

USAGE:
    02_apps[EXE] --two <VALUE> --one <VALUE>

OPTIONS:
    -h, --help           Print help information
        --one <VALUE>    
        --two <VALUE>    
    -V, --version        Print version information

$ 02_apps --version
MyApp 1.0

```
