# feed-rs
A simple feed parser (RSS, Atom, JSON Feed)

The parser library is in feed-rs, with a simple test tool in testurls
