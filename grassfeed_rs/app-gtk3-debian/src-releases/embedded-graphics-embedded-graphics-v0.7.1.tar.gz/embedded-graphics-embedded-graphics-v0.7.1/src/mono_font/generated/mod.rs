// GENERATED CODE DO NOT MODIFY!
// Any manual changes to this file will be overwritten!
pub mod ascii;
pub mod iso_8859_1;
pub mod iso_8859_10;
pub mod iso_8859_13;
pub mod iso_8859_14;
pub mod iso_8859_15;
pub mod iso_8859_16;
pub mod iso_8859_2;
pub mod iso_8859_3;
pub mod iso_8859_4;
pub mod iso_8859_5;
pub mod iso_8859_7;
pub mod iso_8859_9;
pub mod jis_x0201;
