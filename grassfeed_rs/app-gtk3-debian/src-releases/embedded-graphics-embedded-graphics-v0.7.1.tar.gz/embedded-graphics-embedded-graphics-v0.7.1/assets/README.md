# Assets

This is a folder for storing all sorts of misc junk in like documentation screenshots.
