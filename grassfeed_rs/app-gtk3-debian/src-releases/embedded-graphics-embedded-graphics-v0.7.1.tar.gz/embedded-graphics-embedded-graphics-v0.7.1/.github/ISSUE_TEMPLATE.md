- Version of embedded-graphics in use (if applicable): [version here]
- Target: [simulator] / [real hardware]
- If using real hardware: [display driver used]

Please link to the driver on <https://crates.io> if applicable.

## Description of the problem/feature request/other

[description here]

## Test case (if applicable)

```rust
// Failing test case demonstrating the issue here
```
