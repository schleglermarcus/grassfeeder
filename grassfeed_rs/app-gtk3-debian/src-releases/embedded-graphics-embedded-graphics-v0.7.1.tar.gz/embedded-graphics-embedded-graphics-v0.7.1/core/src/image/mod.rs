//! Image drawable trait.

mod image_drawable;

pub use image_drawable::ImageDrawable;
