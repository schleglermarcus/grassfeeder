# UNIC — Unicode Emoji

[![Crates.io](https://img.shields.io/crates/v/unic-emoji.svg)](https://crates.io/crates/unic-emoji)
[![Documentation](https://docs.rs/unic-emoji/badge.svg)](https://docs.rs/unic-emoji/)

This UNIC component implements character properties and algorithms from
[Unicode® Technical Standard #51 - Unicode Emoji](http://unicode.org/reports/tr51/).
