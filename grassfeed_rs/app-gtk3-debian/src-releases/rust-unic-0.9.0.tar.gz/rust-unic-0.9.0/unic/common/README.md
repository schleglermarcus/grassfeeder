# UNIC — Common Utilities

[![Crates.io](https://img.shields.io/crates/v/unic-common.svg)](https://crates.io/crates/unic-common)
[![Documentation](https://docs.rs/unic-common/badge.svg)](https://docs.rs/unic-common/)

This UNIC component provides common types, algorithms and macros not shared
between many components.
