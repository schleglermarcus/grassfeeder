* Copyright 2011-2015 The Rust Project developers.
* Copyright 2013-2016 The rust-url developers.
* Copyright 2015-2017 The Servo Project developers.
* Copyright 2017 The UNIC Project developers.

See [AUTHORS](AUTHORS) for the list of developers.

Licensed under the Apache License, Version 2.0
([LICENSE-APACHE](LICENSE-APACHE) or
<http://www.apache.org/licenses/LICENSE-2.0>) or the MIT license
([LICENSE-MIT](LICENSE-MIT) or <http://opensource.org/licenses/MIT>), at your
option.  All files in the project carrying such notice may not be copied,
modified, or distributed except according to those terms.
