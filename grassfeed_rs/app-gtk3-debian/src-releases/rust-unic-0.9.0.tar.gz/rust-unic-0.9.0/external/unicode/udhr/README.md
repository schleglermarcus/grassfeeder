# A collection of UDHR in Unicode text files

Source: http://unicode.org/udhr/
