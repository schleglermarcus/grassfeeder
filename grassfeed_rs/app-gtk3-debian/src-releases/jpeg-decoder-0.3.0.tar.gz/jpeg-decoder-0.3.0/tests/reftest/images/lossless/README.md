# lossless
The files starting with jpeg_lossless were taken from https://github.com/rii-mango/JPEGLosslessDecoderJS 
The image data bytes were extracted from the DICOM files. 
The reference PNG files were created with the IJG library as distributed in the GDCM toolkit https://github.com/malaterre/GDCM/tree/master/Utilities/gdcmjpeg.