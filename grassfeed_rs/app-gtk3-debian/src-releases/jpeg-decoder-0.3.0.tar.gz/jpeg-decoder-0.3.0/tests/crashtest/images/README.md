# File sources
File                      | Source
--------------------------| ------
imagetestsuite/           | The files in this directory were taken from https://code.google.com/p/imagetestsuite/
dc-predictor-overflow.jpg | Found by Wim Looman (@Nemo157) while fuzzing
derive-huffman-codes-overflow.jpg | Found by Pascal Hertleif (@killercup) while fuzzing
missing-sof.jpg           | Found by Corey Farwell (@frewsxcv) when fuzz testing
extraneous-bytes-after-sos.jpg | Scan from brother DSmobile 920DW provided by Filip Lundborg (@filipl)
missing-sos.jpg           | Generated in GIMP and manually edited by John Reynolds (@quilan1)
missing-frame-image-1410.jpg | Found by @frewsxcv when fuzzing
