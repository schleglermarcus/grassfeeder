# Changelog

## \[0.16.0]

- Update to soup2-sys in sys crate.
  - [eb53cd6](https://github.com/tauri-apps/javascriptcore-rs/commit/eb53cd68667ea35917a75aac4ed9167ddf4bfa0e) Add change file on 2021-12-23

## \[0.15.2]

- Update with lates gir files
  - [cf24027](https://github.com/tauri-apps/javascriptcore-rs/commit/cf240271a1154ff82ae9dcf444fa63d082a8a9f9) Add change file on 2021-11-04

## \[0.15.0]

- Update sys crate to latest gir.
  - [e74374e](https://github.com/tauri-apps/javascriptcore-rs/commit/e74374e9ad6da48a63c457ef8bf21e147e176479) Bump sys crate version on 2021-10-05
