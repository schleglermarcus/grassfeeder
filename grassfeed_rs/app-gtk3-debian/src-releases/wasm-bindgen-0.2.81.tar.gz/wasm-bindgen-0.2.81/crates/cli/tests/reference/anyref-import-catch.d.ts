/* tslint:disable */
/* eslint-disable */
/**
*/
export function exported(): void;
