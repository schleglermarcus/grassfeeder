/* tslint:disable */
/* eslint-disable */
/**
* @returns {string}
*/
export function exported(): string;
