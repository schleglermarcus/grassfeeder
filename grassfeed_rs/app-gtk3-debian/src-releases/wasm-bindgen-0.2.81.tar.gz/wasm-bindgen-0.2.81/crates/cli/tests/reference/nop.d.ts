/* tslint:disable */
/* eslint-disable */
/**
*/
export function nop(): void;
