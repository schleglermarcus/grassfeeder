import * as wasm from './reference_test_bg.wasm';

/**
*/
export function nop() {
    wasm.nop();
}

