/* tslint:disable */
/* eslint-disable */
/**
*/
export function foo(): void;
