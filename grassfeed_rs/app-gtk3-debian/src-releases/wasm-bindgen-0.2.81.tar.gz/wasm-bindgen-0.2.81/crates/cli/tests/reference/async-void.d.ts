/* tslint:disable */
/* eslint-disable */
/**
* @returns {Promise<void>}
*/
export function foo(): Promise<void>;
