/* tslint:disable */
/* eslint-disable */
/**
* @returns {Promise<number>}
*/
export function foo(): Promise<number>;
