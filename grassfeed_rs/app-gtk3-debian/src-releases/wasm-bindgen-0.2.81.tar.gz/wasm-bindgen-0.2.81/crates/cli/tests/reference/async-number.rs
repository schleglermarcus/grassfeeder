use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub async fn foo() -> u32 {
    1
}
