/* tslint:disable */
/* eslint-disable */
/**
* @param {string} a
*/
export function foo(a: string): void;
