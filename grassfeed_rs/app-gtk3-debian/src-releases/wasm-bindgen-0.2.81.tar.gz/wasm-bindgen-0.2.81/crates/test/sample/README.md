# Sample test crate

This is a dummy crate used to test changes to the `wasm-bindgen-test` crate,
this'll never be published nor tested on CI, it's intended for human inspection.
