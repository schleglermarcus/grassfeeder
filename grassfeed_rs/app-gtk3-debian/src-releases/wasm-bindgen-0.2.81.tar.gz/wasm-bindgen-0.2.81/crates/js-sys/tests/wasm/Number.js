
exports.const_epsilon = function() {
    return Number.EPSILON;
};
exports.const_max_safe_integer = function() {
    return Number.MAX_SAFE_INTEGER;
};
exports.const_max_value = function() {
    return Number.MAX_VALUE;
};
exports.const_min_safe_integer = function() {
    return Number.MIN_SAFE_INTEGER;
};
exports.const_min_value = function() {
    return Number.MIN_VALUE;
};
exports.const_negative_infinity = function() {
    return Number.NEGATIVE_INFINITY;
};
exports.const_positive_infinity = function() {
    return Number.POSITIVE_INFINITY;
};
