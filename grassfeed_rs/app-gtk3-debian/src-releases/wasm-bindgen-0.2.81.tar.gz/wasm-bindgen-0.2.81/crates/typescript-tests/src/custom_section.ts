import * as wbg from '../pkg/typescript_tests';

const height: wbg.Height = new wbg.Person();