import initialize from "../../pkg/web/typescript_tests";

const init: Promise<any> = initialize(".");
