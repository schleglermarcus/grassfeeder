import * as wasm from '../pkg/typescript_tests_bg.wasm';

const memory: WebAssembly.Memory = wasm.memory;
