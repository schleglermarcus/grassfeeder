export function jsthunk() {}
export function add(a, b) { return a + b; }
export class Foo {
  bar() {}
}
