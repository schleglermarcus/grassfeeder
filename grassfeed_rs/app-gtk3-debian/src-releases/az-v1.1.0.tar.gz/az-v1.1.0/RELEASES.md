<!-- Copyright © 2019–2021 Trevor Spiteri -->

<!-- Copying and distribution of this file, with or without
modification, are permitted in any medium without royalty provided the
copyright notice and this notice are preserved. This file is offered
as-is, without any warranty. -->

Version 1.1.0 (2021-02-03)
==========================

  * Unwrapped casts were added, which panic on overflow even when
    debug assertions are not enabled.
      * [UnwrappedCast][uc-1-1]
      * [UnwrappedAs][ua-1-1]
      * [unwrapped_cast][ucf-1-1]

[ua-1-1]: https://docs.rs/az/~1.1/az/trait.UnwrappedAs.html
[uc-1-1]: https://docs.rs/az/~1.1/az/trait.UnwrappedCast.html
[ucf-1-1]: https://docs.rs/az/~1.1/az/fn.unwrapped_cast.html

Version 1.0.0 (2020-04-18)
==========================

  * All deprecated items were removed.

Version 0.3.1 (2020-04-17)
==========================

  * Static casts were deprecated as their use case was unclear.

Version 0.3.0 (2019-10-01)
==========================

  * The behavior of static casts was changed: now they return
    `Option`, but an implementation should either always return `Some`
    or always return `None`.
  * Bug fix: checked casts from floating-point to wrapped integers
    were panicking for infinite or NaN.

Version 0.2.0 (2019-09-10)
==========================

  * The old `*As` traits were renamed to `*Cast`.
  * New more convenient `*As` traits were added.

Version 0.1.0 (2019-09-09)
==========================

  * Conversions between integers and floating-point numbers.
  * Checked, saturating, wrapping and overflowing conversions.
  * Static conversions when the conversion cannot fail.
  * Rounding conversions from floating-point numbers to integers using `Round`.
