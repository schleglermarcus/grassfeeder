// These modules contain `compile_fail` doc tests.
mod quicksort_race1;
mod quicksort_race2;
mod quicksort_race3;
mod rc_return;
mod rc_upvar;
mod scope_join_bad;
