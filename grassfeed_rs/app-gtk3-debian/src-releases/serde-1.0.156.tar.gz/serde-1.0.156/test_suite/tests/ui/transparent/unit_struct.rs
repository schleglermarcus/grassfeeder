use serde_derive::Serialize;

#[derive(Serialize)]
#[serde(transparent)]
struct S;

fn main() {}
