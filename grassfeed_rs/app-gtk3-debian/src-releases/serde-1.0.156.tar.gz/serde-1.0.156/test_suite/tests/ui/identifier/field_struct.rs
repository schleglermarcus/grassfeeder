use serde_derive::Deserialize;

#[derive(Deserialize)]
#[serde(field_identifier)]
struct S;

fn main() {}
