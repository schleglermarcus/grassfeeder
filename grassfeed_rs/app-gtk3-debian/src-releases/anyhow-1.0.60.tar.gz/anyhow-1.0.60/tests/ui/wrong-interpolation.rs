use anyhow::{bail, Result};

fn main() -> Result<()> {
    bail!("{} not found");
}
