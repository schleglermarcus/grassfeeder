- Version of tinybmp in use (if applicable): [version here]

## Description of the problem/feature request/other

[description here]

## Test case (if applicable)

```rust
// Failing test case demonstrating the issue here
```
