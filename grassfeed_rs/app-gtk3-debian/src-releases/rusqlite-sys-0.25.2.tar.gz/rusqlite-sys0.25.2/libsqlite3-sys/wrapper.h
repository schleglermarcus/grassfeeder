#ifdef BINDGEN_USE_WINSQLITE3
#include <winsqlite/winsqlite3.h>
#else
#include "sqlite3.h"
#endif
