This folder contains the reference renderings. To save space, they are saved as
PNG images. Since the decoder is not part of the test, the resulting png file
in `output` may differ. Thus a CRC checksum of the image data is saved in the 
filename.

Therefore it is ok to update the reference renderings with files from the 
`output` dir, but it is not ok to add a new file instead.