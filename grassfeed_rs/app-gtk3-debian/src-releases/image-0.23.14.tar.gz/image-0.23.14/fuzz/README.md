# Fuzzing with libfuzzer

For the possibly more up-to-date guide see <https://fuzz.rs/book/cargo-fuzz/setup.html>.

> $ cargo install cargo-fuzz
> $ cargo +nightly fuzz run fuzzer_script_<format>
