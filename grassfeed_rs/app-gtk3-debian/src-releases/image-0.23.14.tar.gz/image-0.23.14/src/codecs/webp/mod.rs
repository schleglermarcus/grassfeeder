//! Decoding of WebP Images

pub use self::decoder::WebPDecoder;

mod decoder;
mod transform;

pub mod vp8;
