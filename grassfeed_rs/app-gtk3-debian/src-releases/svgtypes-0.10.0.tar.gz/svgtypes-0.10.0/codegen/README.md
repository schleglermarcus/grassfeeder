We don't use cargo build script, since this data will be changed rarely.
There is no point in regenerating it each time, only if you want to save a few KiB.

To regenerate files run:

```
cargo run
```
