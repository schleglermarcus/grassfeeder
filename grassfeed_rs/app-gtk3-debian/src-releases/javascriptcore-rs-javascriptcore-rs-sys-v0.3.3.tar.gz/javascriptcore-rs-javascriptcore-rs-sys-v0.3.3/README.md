# javascriptcore

__Rust__ bindings and wrappers for __javascriptcore__.

## Using

```toml
[dependencies]
javascriptcore-rs = "0.14"
```

## License

__javascriptcore-rs__ is available under the MIT License, please refer to it.
