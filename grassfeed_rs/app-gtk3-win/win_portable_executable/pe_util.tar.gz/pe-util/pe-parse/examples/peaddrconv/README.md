Note that you have to install the library before you can build this example!
