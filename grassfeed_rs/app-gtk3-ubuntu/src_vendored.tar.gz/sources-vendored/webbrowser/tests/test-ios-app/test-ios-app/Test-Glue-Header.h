//
//  Test-Glue-Header.h
//  test-ios-app
//
//  Created by Amod Malviya on 05/09/22.
//

#ifndef Test_Glue_Header_h
#define Test_Glue_Header_h

#include <stdint.h>

void test_open_webbrowser(const char* url);

#endif /* Test_Glue_Header_h */
