//! # INI
//!
//! ```rust
#![doc = include_str!("../../examples/ini/parser.rs")]
//! ```
