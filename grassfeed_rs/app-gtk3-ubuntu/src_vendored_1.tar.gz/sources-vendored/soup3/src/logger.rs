use crate::Logger;
use crate::LoggerLogLevel;
use glib::object::IsA;
use glib::translate::*;
use glib::GString;
use std::boxed::Box as Box_;

pub trait LoggerExtManual: 'static {
    #[doc(alias = "soup_logger_set_printer")]
    fn set_printer<P: Fn(&Logger, LoggerLogLevel, char, &str) + Send + Sync + 'static>(
        &self,
        printer: P,
    );
}

impl<O: IsA<Logger>> LoggerExtManual for O {
    fn set_printer<P: Fn(&Logger, LoggerLogLevel, char, &str) + Send + Sync + 'static>(
        &self,
        printer: P,
    ) {
        let printer_data: Box_<P> = Box_::new(printer);
        unsafe extern "C" fn printer_func<
            P: Fn(&Logger, LoggerLogLevel, char, &str) + Send + Sync + 'static,
        >(
            logger: *mut ffi::SoupLogger,
            level: ffi::SoupLoggerLogLevel,
            direction: libc::c_char,
            data: *const libc::c_char,
            user_data: glib::ffi::gpointer,
        ) {
            let logger = from_glib_borrow(logger);
            let direction: glib::Char = from_glib(direction);
            let data: Borrowed<GString> = from_glib_borrow(data);
            let callback: &P = &*(user_data as *mut _);
            (*callback)(&logger, from_glib(level), char::from(direction), data.as_str());
        }
        unsafe extern "C" fn destroy_func<
            P: Fn(&Logger, LoggerLogLevel, char, &str) + Send + Sync + 'static,
        >(
            data: glib::ffi::gpointer,
        ) {
            let _callback: Box_<P> = Box_::from_raw(data as *mut _);
        }
        unsafe {
            ffi::soup_logger_set_printer(
                self.as_ref().to_glib_none().0,
                Some(printer_func::<P> as _),
                Box_::into_raw(printer_data) as *mut _,
                Some(destroy_func::<P> as _),
            )
        }
    }
}
