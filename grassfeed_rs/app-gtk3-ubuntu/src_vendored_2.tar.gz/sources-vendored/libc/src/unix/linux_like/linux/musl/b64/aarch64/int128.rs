s! {
    pub struct user_fpsimd_struct {
        pub vregs: [::__uint128_t; 32],
        pub fpsr: u32,
        pub fpcr: u32,
    }
}
